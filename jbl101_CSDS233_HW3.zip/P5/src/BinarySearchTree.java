public class BinarySearchTree {



    public Node insert(Node root, int key) {
        if(root.getKey() == key) {
            throw new IllegalArgumentException("Key already exists.");
        } else if(key < root.getKey()) {
            if(root.getLeftChild() == null) {
                root.setLeftChild(new Node(key));
            } else {
                insert(root.getLeftChild(), key);
            }
        } else {
            if(root.getRightChild() == null) {
                root.setRightChild(new Node(key));
            } else {
                insert(root.getRightChild(), key);
            }
        }

        return root;

    }

    public void inorder(Node root) {
        if(root.getLeftChild() != null) {
            inorder(root.getLeftChild());
        }

        System.out.println(root.getKey() + " ");

        if(root.getRightChild() != null) {
            inorder(root.getRightChild());
        }

    }

    public int sum(Node root) {

        if(root == null) {
            return 0;
        } else {
            return root.getKey() + sum(root.getRightChild()) + sum(root.getLeftChild());
        }

    }

    public Node search(Node root, int key) {


        if(root == null) {
            return null;
        } else if (root.getKey() == key) {
            return root;
        } else if (root.getKey() > key) {
            return search(root.getLeftChild(), key);
        } else  {
            return search(root.getRightChild(), key);
        }

    }

    public Node kthSmallest(Node root, int k) {

        if(k == 0) {
            if(root == null) {
                throw new ArrayIndexOutOfBoundsException("k is larger than array");

            } else {
                return root;
            }
        } else {

            if (root.getLeftChild() != null) {
                return kthSmallest(root.getLeftChild(), k - 1);
            }

            if (root.getRightChild() != null) {
                return kthSmallest(root.getRightChild(), k - 1);
            }


            return null;

        }
    }

    public Node delete(Node root, int key) {



            if (root == null)
                return root;


            if (key < root.getKey())
                root.setLeftChild(delete(root.getLeftChild(), key));
            else if (key > root.getKey())
                root.setRightChild(delete(root.getRightChild(), key));
            else {
                // node with only one child or no child
                if (root.getLeftChild() == null)
                    return root.getRightChild();
                else if (root.getRightChild() == null)
                    return root.getLeftChild();

                // node with two children: Get the inorder
                // successor (smallest in the right subtree)

                Node smallestRightMost = root;

                while(smallestRightMost != null) {
                    if(smallestRightMost.getLeftChild() != null) {
                        smallestRightMost = smallestRightMost.getLeftChild();
                    } else {
                        break;
                    }
                }

                root.setKey(smallestRightMost.getKey());

                root.setRightChild(delete(root.getRightChild(), root.getKey()));
            }

            return root;
        }





}
